﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            pictureBox3.Image=null;
            trackBar1.Value=0;
            label6.Text = null;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double v = double.Parse(textBox2.Text);
            double r = double.Parse(textBox1.Text);
            double i = v / ((r / 100) * (r / 100));
            label6.Text = i.ToString("##.##");
            trackBar1.Value = Convert.ToInt32(i);
            if (radioButton1.Checked)
            {

                if (i < 18.5)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\student\source\repos\marafon_by_Gulov\marafon_by_Gulov\Resoures\bmi-underweight-icon.png");
                }
                if (i > 25)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\student\source\repos\marafon_by_Gulov\marafon_by_Gulov\Resoures\bmi-overweight-icon.png");
                }
                if (i >= 18.5)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\student\source\repos\marafon_by_Gulov\marafon_by_Gulov\Resoures\bmi-healthy-icon.png");
                }
                if (i > 30)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\student\source\repos\marafon_by_Gulov\marafon_by_Gulov\Resoures\bmi-obese-icon.png");
                }
            }
            if (radioButton2.Checked)
            {
                if (i < 18.5)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\student\source\repos\marafon_by_Gulov\marafon_by_Gulov\Resoures\female-icon.png");
                }
                if (i > 25)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\student\source\repos\marafon_by_Gulov\marafon_by_Gulov\Resoures\bmi-overweight-icon.png");
                }
                if (i >= 18.5)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\student\source\repos\marafon_by_Gulov\marafon_by_Gulov\Resoures\female-icon.png");
                }
                if (i > 45)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\student\source\repos\marafon_by_Gulov\marafon_by_Gulov\Resoures\bmi-obese-icon.png");
                }
            }
        }

    }
}
