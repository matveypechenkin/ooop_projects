﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            panel4.Visible = true;
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            panel5.Visible = true;
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            panel6.Visible = true;
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            panel7.Visible = true;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            panel8.Visible = true;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void label13_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
        }

        private void label15_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {
            panel4.Visible = false;
        }

        private void label20_Click(object sender, EventArgs e)
        {
            panel5.Visible = false;
        }

        private void label22_Click(object sender, EventArgs e)
        {
            panel6.Visible = false;
        }

        private void label24_Click(object sender, EventArgs e)
        {
            panel7.Visible = false;
        }

        private void label26_Click(object sender, EventArgs e)
        {
            panel8.Visible = false;
        }
    }
}
