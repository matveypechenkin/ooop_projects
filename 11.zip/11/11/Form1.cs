﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double v = double.Parse(textBox2.Text);
            double r = double.Parse(textBox1.Text);
            double i = v / ((r / 100) * (r / 100));
            label6.Text = i.ToString("##.##");
            trackBar1.Value = Convert.ToInt32(i);
            if (radioButton1.Checked)
            {

                if (i < 18.5)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\matve\Desktop\Учеба3курс\OOOP\сдача на гитхаб\распакованное\Марафон-калькуляторы\marafon\bmi-underweight-icon.png");
                }
                if (i >= 18.5)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\matve\Desktop\Учеба3курс\OOOP\сдача на гитхаб\распакованное\Марафон-калькуляторы\marafon\male-icon.png");
                }
                if (i > 25)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\matve\Desktop\Учеба3курс\OOOP\сдача на гитхаб\распакованное\Марафон-калькуляторы\marafon\bmi-overweight-icon.png");
                }
                if (i > 30)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\matve\Desktop\Учеба3курс\OOOP\сдача на гитхаб\распакованное\Марафон-калькуляторы\marafon\bmi-obese-icon.png");
                }
            }
            if (radioButton2.Checked)
            {
                if (i < 18.5)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\matve\Desktop\Учеба3курс\OOOP\сдача на гитхаб\распакованное\Марафон-калькуляторы\marafon\hud-woman.png");
                }
                if (i >= 18.5)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\matve\Desktop\Учеба3курс\OOOP\сдача на гитхаб\распакованное\Марафон-калькуляторы\marafon\female-icon.png");
                }
                if (i > 25)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\matve\Desktop\Учеба3курс\OOOP\сдача на гитхаб\распакованное\Марафон-калькуляторы\marafon\izb-woman.png");
                }
                if (i > 45)
                {
                    pictureBox3.Image = Image.FromFile(@"C:\Users\matve\Desktop\Учеба3курс\OOOP\сдача на гитхаб\распакованное\Марафон-калькуляторы\marafon\tolst-woman.png");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            pictureBox3.Image = null;
            trackBar1.Value = 0;
            label6.Text = null;
        }
    }
}
